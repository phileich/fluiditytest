package bftsmart.dynamicWeights;

public class ClientLatency extends Latency {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9019102733615993633L;

}
