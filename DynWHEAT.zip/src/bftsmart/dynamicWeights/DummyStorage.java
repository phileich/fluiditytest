package bftsmart.dynamicWeights;

import java.util.List;

public class DummyStorage implements Storage{

	@Override
	public List<Latency> getClientLatencies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Latency[]> getServerLatencies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Latency[]> getServerProposeLatencies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void clearAll() {
		// TODO Auto-generated method stub
		
	}

}
